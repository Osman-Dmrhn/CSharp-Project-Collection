﻿using BlogApplication.Models;

namespace BlogApplication.Services
{
    public interface ICategoryService
    {
        List<Category> GetCategories();

        void AddCategory(Category category);
        void RemoveCategory(Guid id);
        void UpdateCategory(Category category);
    }
}
