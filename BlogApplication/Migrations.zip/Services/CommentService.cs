﻿using BlogApplication.Db;
using BlogApplication.Models;

namespace BlogApplication.Services
{
    public class CommentService
    {
        private readonly EfContext _efContext;

        public CommentService(EfContext efContext)
        {
            _efContext = new EfContext();
        }

        public List<Comment> GetComments()
        {
            return _efContext.Yorumlar.OrderBy(c => c.CreatedAt).ToList();
        }

        public void AddComment(Comment comment)
        {
            _efContext.Yorumlar.Add(comment);
            _efContext.SaveChanges();
        }

        public void RemoveComment(Guid id)
        {
            var commentToRemove = _efContext.Yorumlar.Find(id);
            if (commentToRemove is null)
                return;

            _efContext.Yorumlar.Remove(commentToRemove);
            _efContext.SaveChanges();
        }

        public void UpdateComment(Comment comment)
        {
            var commentToUpdate = _efContext.Yorumlar.Find(comment.Id);
            if (commentToUpdate != null)
            {
                commentToUpdate.Content = comment.Content;
            }

            _efContext.Yorumlar.Update(comment);
            _efContext.SaveChanges();
        }
    }
}
