﻿using BlogApplication.Db;
using BlogApplication.Models;

namespace BlogApplication.Services
{
    public class BlogService
    {
        private readonly EfContext _efContext;

        public BlogService(EfContext efContext)
        {
            _efContext = efContext;
        }
        List<Blog> GetAll()
        {
            var list = _efContext.Bloglar.OrderBy(x=>x.Id).ToList();
            return list;
        }
        void addBlog(Blog blog)
        {
            _efContext.Bloglar.Add(blog);
            _efContext.SaveChanges();
        }
        void removeBlog(Guid id)
        {
            var silinecek= _efContext.Bloglar.Find(id);
            if (silinecek is null)
                return;
            _efContext.Remove(silinecek);
            _efContext.SaveChanges();
        }

        void UpdateBlog(Blog blog)
        {
            var guncellenecek = _efContext.Bloglar.Find(blog.Id);
            if (guncellenecek is not null)
            {
                guncellenecek.Icerik=blog.Icerik;
                guncellenecek.Aciklama=blog.Aciklama;
                guncellenecek.Baslik = blog.Baslik;
            }
            _efContext.Bloglar.Update(guncellenecek);
            _efContext.SaveChanges();
        }
    }
}
