﻿using BlogApplication.Models;

namespace BlogApplication.Services
{
    public interface ICommentService
    {
        List<Comment> GetAll();
        void AddComment(Comment comment);
        void RemoveComment(Guid id);
        void UpdateComment(Comment comment);
    }
}
