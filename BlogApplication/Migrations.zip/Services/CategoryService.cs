﻿using BlogApplication.Db;
using BlogApplication.Models;

namespace BlogApplication.Services
{
    public class CategoryService
    {
        private readonly EfContext _efContext;

        public CategoryService(EfContext efContext)
        {
            _efContext = new EfContext();
        }
        List<Category> GetCategories()
        {
            var list = _efContext.Kategoriler.OrderBy(x=>x.KategoriAdi).ToList();
            return list;
        }

        void AddCategory(Category category)
        {
            _efContext.Kategoriler.Add(category);
            _efContext.SaveChanges();
        }
        void RemoveCategory(Guid id)
        {
            var silinecek =_efContext.Kategoriler.Find(id);

            if (silinecek is null)
                return;
            _efContext.Kategoriler.Remove(silinecek);
            _efContext.SaveChanges();
        }
        void UpdateCategory(Category category)
        {
            var guncellenecek=_efContext.Kategoriler.Find(category.Id);
            if (guncellenecek != null)
            {
                guncellenecek.KategoriAdi = category.KategoriAdi;
            }
            _efContext.Kategoriler.Update(category);
            _efContext.SaveChanges();
        }
    }
}
