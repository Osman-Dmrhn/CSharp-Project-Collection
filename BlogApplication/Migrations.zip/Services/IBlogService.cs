﻿using BlogApplication.Models;

namespace BlogApplication.Services
{
    public interface IBlogService
    {
        List<Blog> GetAll();
        void addBlog(Blog blog);
        void removeBlog(Guid id);

        void UpdateBlog(Blog blog);
    }
}
