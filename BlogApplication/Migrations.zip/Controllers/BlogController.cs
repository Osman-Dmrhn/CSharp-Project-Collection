﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BlogApplication.Controllers
{
    [Authorize]
    public class BlogController : Controller
    {
        public IActionResult BlogView()
        {
            return View();
        }

        public ViewResult addBlog()
        {
            return View();
        }

        public ViewResult removeBlog()
        {
            return View();
        }
        public ViewResult editBlog()
        {
            return View();
        }
    }
}
